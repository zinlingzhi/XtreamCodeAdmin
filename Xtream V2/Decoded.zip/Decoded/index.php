<?php
/*Rev:26.09.18r0*/

echo 'Access Denied.';
?>
